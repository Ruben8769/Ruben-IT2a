import backend

def main():
    print("\n--- Start Meny ---\n\n1) Logg in\n2) Registrer bruker\n9) Avslutt\n")
    choise = input("Velg:")
    while True:
        if choise == "1":
            pass
        elif choise == "2":
            pass
        elif choise == "9":
            break
        else:
            print("Ugyldig inntastet, prøv på nytt.")

def login():
    pass




main()