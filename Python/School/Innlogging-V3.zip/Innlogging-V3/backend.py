import sqlite3

try:
    conn = sqlite3.connect("database.db")
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    sql = "SELECT name, password FROM accounts"
    account_data = cursor.execute(sql).fetchall()
except Exception as e:
    print(f"Feilmelding: {e}")

name = input("Name: ")
password = input("Passord: ")
choices = [name, password]

try:
    add_sql = "INSERT INTO accounts (name, password) VALUES (?, ?)"
    cursor.execute(add_sql, choices)
    conn.commit()
except Exception as e:
    print(f"Feilmelding: {e}")